import setuptools
with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
     name='BVlain',  
     version='0.0.5.2',
     py_modules = ["BVlain"],
     install_requires = ["numpy", "pandas", "scipy", "networkx"],
     author="Artem Dembitskiy",
     author_email="art.dembitskiy@gmail.com",
     description="The Bond valence site energy calculator",
     long_description=long_description,
    long_description_content_type="text/markdown",
     url="https://github.com/dembart/BVLain",
     package_data={"BVlain": ["*.txt", "*.rst","*"]},
     classifiers=[
         "Programming Language :: Python :: 3",
         "License :: OSI Approved :: MIT License",
         "Operating System :: OS Independent",
     ],
    include_package_data=True,
    package_dir={'': 'src'},
    packages=setuptools.find_packages(where="src")
 )


