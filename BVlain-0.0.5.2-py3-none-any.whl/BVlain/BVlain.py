import os
#import pymatgen #not necessary
from pymatgen.core import Structure
from pymatgen.core import PeriodicSite
#from pymatgen.io.cif import CifParser #not necessary
import numpy as np
import pandas as pd
import networkx as nx
#import matplotlib.pyplot as plt #not necessary
from scipy.spatial.ckdtree import cKDTree
#from mpl_toolkits.mplot3d import Axes3D #not necessary

from scipy.special import erfc
import time 
import imp
import re

def structure_read(path_to_cif):
        try:
            struct = Structure.from_file(path_to_cif)
            return struct
        except UnicodeDecodeError:
            return print("You failed")

def build(mobile_ion = None, path_to_tables = None):
    if type(path_to_tables) != str:

        path_to_tables = imp.find_module("BVlain")[1].replace("/BVlain.py","").replace("BVlain.py","")
    mobile_element = re.sub('\d', '', mobile_ion).replace("+","").replace("-","")

    ##importing BVparams
    ##setting test ion params
    ##setting calculation params: R_cut, f_sc, resolution, accuracy, grid step, maximum barrier of interests
    df_sft = pd.read_csv(path_to_tables + "/" + "database_unitary.txt",sep = "\t") 

    df_BV=pd.read_csv(path_to_tables + "/" + "database_binary.txt",sep = "\t") 
    df_BV["os-"] = df_BV["os-"].astype(int)
    df_BV["os+"] = df_BV["os+"].astype(int)
    sf_mobile_ion = float(df_sft[df_sft["ty"] == mobile_element]["sf"])

    g_mobile_ion = float(df_sft[df_sft["ty"] == mobile_element]["g"])
    V_mobile_ion = float(df_sft[df_sft["ty"] == mobile_element]["os"])
    R_c_mobile_ion = float(df_sft[df_sft["ty"] == mobile_element]["rc"])

    df_sft = df_sft.rename(columns = {"ty":"Type-","os":"os-","b":"block"})
    df_sft[df_sft["Type-"] == mobile_element]
    df_sft= df_sft[["Type-","os-","sf","g","block","rc"]]

    df_sft["os-"] = df_sft["os-"].astype(int)
    df_sft["g"] = df_sft["g"].astype(int)
    return sf_mobile_ion, g_mobile_ion, V_mobile_ion, R_c_mobile_ion, df_sft, df_BV, mobile_element


def grid(struct = None, resolution = None):
    a_grid = [0 + resolution*(i) for i in range(int(struct.lattice.a//resolution))]
    b_grid = [0 + resolution*(i) for i in range(int(struct.lattice.b//resolution))]
    c_grid = [0 + resolution*(i) for i in range(int(struct.lattice.c//resolution))]
    a_grid.append(struct.lattice.a)
    #print(struct.lattice.a)
    #print(struct.lattice.b)
    b_grid.append(struct.lattice.b)
    c_grid.append(struct.lattice.c)
    a_grid = np.array(a_grid)/struct.lattice.a
    b_grid = np.array(b_grid)/struct.lattice.b
    c_grid = np.array(c_grid)/struct.lattice.c
    size = [len(a_grid), len(b_grid), len(c_grid)]

    grid_table = np.vstack(np.meshgrid(b_grid,a_grid,c_grid)).reshape(3,-1).T
    grid_table = pd.DataFrame({"a_b_c":tuple(grid_table)})
    grid_table = grid_table["a_b_c"].apply(pd.Series)####BOTLENECK
    c_copy = grid_table[0].copy()
    grid_table[0] = grid_table[1]
    grid_table[1] = c_copy
    grid_table = grid_table.values.tolist()
    grid_table = pd.DataFrame({"a_b_c":tuple(grid_table)})
    size = [len(a_grid), len(b_grid), len(c_grid)]
    return grid_table, size



def site_popul(pos, mobile_ion = None, struct = None):
    return PeriodicSite(species = mobile_ion,lattice = struct.lattice, coords = pos)



def BVEL(struct = None, grid_table = None,r_cut = None, f_sc = 0.74, path_to_tables = None, mobile_ion = None):
    sf_mobile_ion, g_mobile_ion, V_mobile_ion,R_c_mobile_ion, df_sft, df_BV, mobile_element = build(mobile_ion = mobile_ion)
    specie_prop = pd.DataFrame()
    for i in range(len(struct.sites)):
        specie_prop = specie_prop.append(struct.sites[i].as_dict()["species"][0], ignore_index = True)
    specie_prop["neigh"] = [i for i in range(len(specie_prop))]  
    

    ar = struct.get_neighbor_list(r_cut, sites = grid_table["site"])

    table = pd.DataFrame({"center":ar[0],"neigh":ar[1],"R":ar[3]})
    table = table.merge(specie_prop)
    table = table.rename(columns = {"oxidation_state":"os-","element":"Type-"})
    table["Type+"] = mobile_element
    table["os+"] = V_mobile_ion
    table_n = table[table["os-"] < 0]
    table_p = table[table["os-"] > 0] 
    table_n = table_n.merge(df_BV)
    table_n = table_n.merge(df_sft)

    table_n["R_min"] = (0.9185 + 0.2285*abs(table_n["sf"] - sf_mobile_ion))*table_n["R0(A)"] - table_n["b"]*\
    np.log(V_mobile_ion/table_n["cn"])

    table_n["D_0"] = abs(14.4*V_mobile_ion*table_n["os-"]*\
                 (table_n["b"]**2)/((2*table_n["R_min"])*(table_n["g"]*g_mobile_ion)**(1/2)))

    table_n["E_bond"] = (table_n["D_0"]*\
                 (np.exp((table_n["R_min"] - table_n["R"])/table_n["b"])-1)**2 - table_n["D_0"])*table_n["occu"]

    table_p = table_p.merge(df_sft)
    ## check the following line precisely
    table_p["coulomb"] = 14.4*table_p["occu"]*V_mobile_ion*table_p["os-"]/(table_p["R"]*(g_mobile_ion*table_p["g"])**(1/2))*\
    erfc(table_p["R"]/(f_sc*(R_c_mobile_ion + table_p["rc"])))

    table_p = table_p.groupby(["center"]).sum(["coulomb"])
    table_n = table_n.groupby(["center"]).sum(["E_bond"])
    BVSE = table_p["coulomb"] + table_n["E_bond"]
    return BVSE.replace([np.inf, -np.inf], 10**5)

def volume_data_writer_vesta(name = None, struct = None, path_to_output = None, grid_table = None, size = None, resolution = None):
    
    dirName = path_to_output + "/"
    with open(dirName + name + "_" + str(resolution) + ".grd" , "w") as file:
        file.write(name + "\n")
        vectors = [struct.lattice.a, struct.lattice.b, struct.lattice.c]
        for vector in vectors:
            file.write(str(vector) + " ")
        angles = str(struct.lattice.alpha) + " " + str(struct.lattice.beta) + " " +  str(struct.lattice.gamma) + "\n"
        voxels = size
        file.write(angles)
        for voxel in voxels:
                  file.write(str(voxel) + " ")
        file.write("\n")
        for val in grid_table["BVSE"]:
            file.write(str(val) + "\n")  


def path_dim(data = None,E_tr = None, ax = None, size = None):
    data = np.array(data).reshape(size[0],size[1],size[2])

    # find coordinates
    cs = np.argwhere(data < E_tr)

    # build k-d tree
    kdt = cKDTree(cs)
    edges = kdt.query_pairs(2**(1/2))

    # create graph
    G = nx.from_edgelist(edges)

    # find connected components
    ccs = nx.connected_components(G)
    node_component = {v:k for k,vs in enumerate(ccs) for v in vs}

    # percolation along axis
    df = pd.DataFrame(cs, columns=['x','y','z'])
    df['c'] = pd.Series(node_component, dtype= "float64")
    dimens = dict()

    ax_0 = df[df[ax] == 0]
    if len(ax_0) == 0:
        return "isolated"
    if ax == "x":
        max_val = size[0] - 1
    if ax == "y":
        max_val = size[1] - 1 
    if ax == "z":
        max_val = size[2] - 1

    ax_0_a = df[df[ax] == max_val]
    
    #fig = plt.figure(figsize=(20,20))
    #axs = plt.subplots(2, 2)
    #ax = fig.add_subplot(111, projection='3d')
    # Hide grid lines
    #ax.grid(False)

    # Hide axes ticks
    #ax.set_xticks([])
    #ax.set_yticks([])
    #ax.set_zticks([])
    #plt.axis('off')
    #cmhot = plt.get_cmap("hot")
    #ax.scatter(df['x'], df['y'], df['z'], c=df['c'], s=50, cmap=cmhot)
    if len(set(np.array(ax_0["c"]))&set(np.array(ax_0_a["c"]))) > 0:
        return E_tr
    else:
        return "isolated"

    # to include single-node connected components
    # df.loc[df['c'].isna(), 'c'] = df.loc[df['c'].isna(), 'c'].isna().cumsum() + df['c'].max()





def dimens_barrier(grid_table = None, size = None, E_tr = None):
    E_min = min(grid_table["BVSE"])
    dimens = dict()
    for ax in ["x", "y", "z"]:
        for en in E_tr:
            if type(path_dim(data = grid_table["BVSE"],E_tr = en, ax = ax, size =size)) == str:
                dimens.update({"E_tr_" + ax: np.inf})
            else: 
                dimens.update({"E_tr_" + ax: abs(E_min - en)})
                print(E_min, en)
                break
    dimens.update({"E_tr_min":min(dimens.values())})
    return dimens



def barrier(name = "Lain", struct = None, 
            mobile_ion = None, r_cut = 8, f_sc = 0.74, resolution = 0.25,
            E_step = 0.1, E_cut = 5, species_to_remove = None,
            vesta = None, path_to_cif = None, path_to_output = None, path_to_tables = None, 
            report = None):
    if struct == None:
        if type(path_to_cif) == str:
            struct = structure_read(path_to_cif)

    if type(species_to_remove) == list:
        species_to_remove.extend([mobile_ion])
    if type(species_to_remove) !=list:
        species_to_remove = list()
        species_to_remove.extend([mobile_ion])

    print("The following species will be removed:", species_to_remove)
    s = time.time()
    
    for specie in species_to_remove:
        struct.remove_species([specie])
    
    results_loc = dict()
    results_loc.update({"name":name})
    
    grid_table, size = grid(resolution = resolution, struct = struct)
    grid_table["site"] = grid_table["a_b_c"].apply(site_popul,mobile_ion = mobile_ion, struct = struct)

    grid_table["BVSE"] = BVEL(struct = struct, grid_table = grid_table,
                              r_cut = r_cut, path_to_tables = path_to_tables, mobile_ion = mobile_ion)
    if vesta == 1:
        volume_data_writer_vesta(name = name, struct = struct, path_to_output = path_to_output, grid_table = grid_table, size = size, resolution = resolution)
        #write report
    E_min = round(min(grid_table["BVSE"]),1)
    E_tr = np.arange(E_min, E_min + E_cut, E_step)
    dimens = dimens_barrier(grid_table = grid_table,size = size, E_tr = E_tr)
    results_loc.update(dimens)
    t = time.time() - s
    results_loc.update({"time":t})
    if report == 1:
        results = pd.DataFrame()
        results = results.append(results_loc, ignore_index = True)
        results = results.round(decimals = 3)
        results.to_csv(path_to_output + "/report_" + name + ".txt", sep = "\t", index = False)
        print("report was written")

    return results_loc